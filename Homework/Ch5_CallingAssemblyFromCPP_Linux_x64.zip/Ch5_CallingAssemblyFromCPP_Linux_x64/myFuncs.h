extern "C" long long addTwo(long long a, long long b);

//long long = 64bits (double word)
//
extern "C" long long addArray(long long a[], long b);

extern "C" void swapArrays(long long a[], long long b[], long long arraySize);
